
import streamlit as st
import pandas as pd
import os
from dotenv import load_dotenv
from google.oauth2 import service_account
import gspread
from datetime import datetime

# .env dosyasını yükle
load_dotenv()

# Google Drive kimlik bilgilerini oku
credentials_info = {
    "type": os.getenv("TYPE"),
    "project_id": os.getenv("PROJECT_ID"),
    "private_key_id": os.getenv("PRIVATE_KEY_ID"),
    "private_key": os.getenv("PRIVATE_KEY").replace("\\n", "\n"),
    "client_email": os.getenv("CLIENT_EMAIL"),
    "client_id": os.getenv("CLIENT_ID"),
    "auth_uri": os.getenv("AUTH_URI"),
    "token_uri": os.getenv("TOKEN_URI"),
    "auth_provider_x509_cert_url": os.getenv("AUTH_PROVIDER_CERT_URL"),
    "client_x509_cert_url": os.getenv("CLIENT_CERT_URL"),
}

credentials = service_account.Credentials.from_service_account_info(credentials_info)
gc = gspread.authorize(credentials)

st.set_page_config(page_title="CSI:GLOBAL - Uç Aşınma Veri Girişi", layout="centered")
st.title("CSI:GLOBAL - Uç Aşınma Analiz Formu (Wear Analysis Form)")

# Form başlıyor
with st.form("wear_form"):
    st.subheader("Uç Bilgileri (Tool Information)")

    tool_code = st.text_input("1. Uç ISO Kodu (Tool ISO Code)")
    chipbreaker = st.text_input("2. Talaş Kırıcı (Chipbreaker)")
    tool_grade = st.text_input("3. Kalite Kodu (Grade Code)")

    st.subheader("İşleme Parametreleri (Machining Parameters)")

    material_options = ["Structural Steel", "Tool Steel", "Stainless Steel", "Cast Iron", "Aluminum Alloy", "Super Alloy"]
    material = st.selectbox("4. İşlenen Malzeme (Workpiece Material)", material_options)

    cutting_speed = st.number_input("5. Kesme Hızı (Cutting Speed) [m/min]", min_value=0.0, step=0.1)
    feed_rate = st.number_input("6. İlerleme (Feed per Revolution) [mm/rev]", min_value=0.0, step=0.01)
    depth_of_cut = st.number_input("7. Talaş Derinliği (Depth of Cut) [mm]", min_value=0.0, step=0.1)

    st.subheader("Görseller (Images)")

    tool_image = st.file_uploader("8. Uç Görseli Yükle (Upload Tool Image)", type=["jpg", "jpeg", "png"])
    chip_image = st.file_uploader("9. Opsiyonel: Talaş Görseli Yükle (Upload Chip Image)", type=["jpg", "jpeg", "png"])

    submit = st.form_submit_button("Kaydet (Save)")

if submit:
    st.success("✅ Veriniz başarıyla kaydedildi! (Your data has been saved!)")

    # Basit Aşınma Analiz Algoritması
    if cutting_speed > 200:
        wear_type = "Crater Wear (Krater Aşınması)"
        advice = "Kesme hızınızı %10 azaltın."
    elif feed_rate > 0.3:
        wear_type = "Flank Wear (Yanak Aşınması)"
        advice = "İlerlemenizi %10 azaltın."
    elif depth_of_cut > 2:
        wear_type = "Notching (Çentik Aşınması)"
        advice = "Talaş derinliğini azaltın."
    else:
        wear_type = "Hafif Flank Wear (Light Flank Wear)"
        advice = "Parametreleriniz uygun görünüyor."

    st.info(f"🔍 Tahmini Aşınma Tipiniz (Estimated Wear Type): **{wear_type}**")
    st.warning(f"💡 Tavsiye (Suggestion): {advice}")

    # Verileri CSV'ye kaydet
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    new_data = pd.DataFrame({
        "timestamp": [timestamp],
        "tool_code": [tool_code],
        "chipbreaker": [chipbreaker],
        "tool_grade": [tool_grade],
        "material": [material],
        "cutting_speed": [cutting_speed],
        "feed_rate": [feed_rate],
        "depth_of_cut": [depth_of_cut],
        "wear_type_estimation": [wear_type],
        "advice_given": [advice]
    })

    try:
        sh = gc.open("CSI_GLOBAL_DATA")
    except:
        sh = gc.create("CSI_GLOBAL_DATA")

    try:
        worksheet = sh.worksheet("Wear_Records")
    except:
        worksheet = sh.add_worksheet(title="Wear_Records", rows="1000", cols="20")

    existing_data = pd.DataFrame(worksheet.get_all_records())
    updated_data = pd.concat([existing_data, new_data], ignore_index=True)
    worksheet.clear()
    worksheet.update([updated_data.columns.values.tolist()] + updated_data.values.tolist())
